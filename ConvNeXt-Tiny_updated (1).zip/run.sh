#!/usr/bin/env bash
set -e

python src/train.py --dataset dataset "$@"
python src/generate_paper.py
