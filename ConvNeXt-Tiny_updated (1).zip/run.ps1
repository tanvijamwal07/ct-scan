param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ArgsList
)

python src/train.py --dataset dataset @ArgsList
python src/generate_paper.py
